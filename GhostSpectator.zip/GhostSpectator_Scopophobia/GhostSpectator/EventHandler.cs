﻿using MEC;
using Smod2;
using Smod2.API;
using Smod2.EventHandlers;
using Smod2.Events;
using Smod2.EventSystem.Events;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Assets._Scripts.Dissonance;
using UnityEngine;

namespace Smod.GhostSpectatorPlugin


{
	class EventHandler : IEventHandlerSetConfig, IEventHandlerSpawnRagdoll, IEventHandlerSetRole, IEventHandlerSummonVehicle, IEventHandlerTeamRespawn, IEventHandlerRoundStart, IEventHandlerPlayerHurt, IEventHandlerShoot, IEventHandlerFixedUpdate, IEventHandlerPlayerPickupItem, IEventHandlerPlayerDropItem, IEventHandlerDoorAccess, IEventHandlerElevatorUse, IEventHandlerPlayerDie, IEventHandlerIntercom, IEventHandlerSCP914Activate, IEventHandlerSCP914ChangeKnob
	{
		private Plugin plugin;
		public static int maxRespawnAmount;
		public static bool allowGhostToDamage;
		public static bool blockDoors;
        public static bool ghostGhostMode;
        public static string ghostBroadcast;
		public static int ghostBroadcastTime;

		public class ShowGhost
		{
			public int playerId;

			public float remainingTime;
		}

		public class Ghost
		{
			public int playerId;

			public float remainingTime;

			public Vector spawnPos;
		}

		public List<ShowGhost> ghostList = new List<ShowGhost>();

		public List<Ghost> spawnGhost = new List<Ghost>();
        private Vector killerpos;
        private Vector tpos;
        private Vector pos;

        public EventHandler(Plugin plugin)
		{
			this.plugin = plugin;
		}

		public void OnRoundStart(RoundStartEvent ev)
		{
			maxRespawnAmount = ConfigManager.Manager.Config.GetIntValue("maximum_MTF_respawn_amount", 35);
			allowGhostToDamage = ConfigManager.Manager.Config.GetBoolValue("gs_allow_ghosts_to_damage", false);
			blockDoors = ConfigManager.Manager.Config.GetBoolValue("gs_block_doors_for_ghosts", true);
			ghostGhostMode = ConfigManager.Manager.Config.GetBoolValue("gs_ghost_mode", true);
			ghostBroadcast = ConfigManager.Manager.Config.GetStringValue("gs_spawn_broadcast", "<size=40>You've been spawned as a <color=#9E9E9E>Ghost</color>! \n Drop the <color=#ABFDFF>coin</color> to teleport to random <color=green>player</color>.</size> <size=25>\n You <color=red>cannot</color> pickup or drop <color=lime>items</color>. \n You <color=red>cannot</color> interact with <color=#FFFA5A>doors</color> or <color=#FFFA5A>elevators</color>. \n You <color=lime>can</color> talk to others. \n You will <color=lime>respawn</color> soon.</size>");
			ghostBroadcastTime = ConfigManager.Manager.Config.GetIntValue("gs_spawn_broadcast_time", 20);
		}

		public void OnSpawnRagdoll(PlayerSpawnRagdollEvent ev)
		{
			spawnGhost.Add(new Ghost { playerId = ev.Player.PlayerId, remainingTime = 3f, spawnPos = ev.Position });
		}

		public void OnSetConfig(SetConfigEvent ev)
		{
			if (ev.Key.Equals("scp173_ignored_role") || ev.Key.Equals("scp096_ignored_role"))
			{
				ev.Value = new List<int> { 2, 14 };
			}
		}

		public void OnSetRole(PlayerSetRoleEvent ev)
		{
			if (ev.Role == Smod2.API.RoleType.SPECTATOR)
			{
				spawnGhost.Add(new Ghost { playerId = ev.Player.PlayerId, remainingTime = 3f, spawnPos = Vector.Zero });
			}
			if (ev.Role == Smod2.API.RoleType.TUTORIAL)
			{

			}
			else
			{
				ev.Player.SetGodmode(false);
				ev.Player.SetGhostMode(false);
			}
		}


		public void OnSummonVehicle(SummonVehicleEvent ev)
		{
			if (!ev.AllowSummon)
			{
				foreach (Player player in plugin.PluginManager.Server.GetPlayers())
				{
					if (player.TeamRole.Team == TeamType.TUTORIAL)
					{
						ev.AllowSummon = true;
						return;
					}
				}
			}
		}

		public void OnTeamRespawn(TeamRespawnEvent ev)
		{
			List<Player> list = (from item in plugin.PluginManager.Server.GetPlayers()
								 where (item.TeamRole.Role == Smod2.API.RoleType.TUTORIAL || item.TeamRole.Role == Smod2.API.RoleType.SPECTATOR) && !item.OverwatchMode
								 select item).ToList();

			System.Random random = new System.Random();
			while (list.Count > maxRespawnAmount)
			{
				list.RemoveAt(random.Next(0, list.Count));
			}

			ev.PlayerList = list;
		}

		public void OnPlayerHurt(PlayerHurtEvent ev)
		{
			if (ev.Attacker.TeamRole.Role == Smod2.API.RoleType.TUTORIAL)
			{
				if (!allowGhostToDamage)
				{
					ev.Damage = 0f;
				}
			}
		}

		public void OnDoorAccess(PlayerDoorAccessEvent ev)
		{
			if (blockDoors && ev.Player.TeamRole.Role == Smod2.API.RoleType.TUTORIAL)
			{
				ev.Allow = false;
			}
		}

		public void OnElevatorUse(PlayerElevatorUseEvent ev)
		{
			if (blockDoors && ev.Player.TeamRole.Role == Smod2.API.RoleType.TUTORIAL)
			{
				ev.AllowUse = false;
			}
		}

		public void OnShoot(PlayerShootEvent ev)
		{
			if (ev.Player.TeamRole.Role == Smod2.API.RoleType.TUTORIAL && ev.Player.GetGhostMode() == true)
			{
				foreach (ShowGhost ghost in ghostList)
				{
					if (ghost.playerId == ev.Player.PlayerId)
					{
						ghost.remainingTime = 3f;
						//ev.Player.SetGhostMode(false);
						return;
					}
				}

				ghostList.Add(new ShowGhost { playerId = ev.Player.PlayerId, remainingTime = 3f });
				//ev.Player.SetGhostMode(false);
			}
		}

		public void OnFixedUpdate(FixedUpdateEvent ev)
		{
			for (int i = 0; i < ghostList.Count; i++)
			{
				ghostList[i].remainingTime -= 0.02f;
				if (ghostList[i].remainingTime <= 0)
				{
					foreach (Player player in (from item in plugin.PluginManager.Server.GetPlayers()
											   where (item.PlayerId == ghostList[i].playerId && item.TeamRole.Team == TeamType.TUTORIAL)
											   select item).ToList())
					{
						player.SetGhostMode(true);
					}
					ghostList.RemoveAt(i);
				}
			}

			for (int i = 0; i < spawnGhost.Count; i++)
			{
				spawnGhost[i].remainingTime -= 0.02f;
				if (spawnGhost[i].remainingTime <= 0)
				{
					foreach (Player player in (from item in plugin.PluginManager.Server.GetPlayers()
											   where (item.PlayerId == spawnGhost[i].playerId)
											   select item).ToList())
					{
						player.ChangeRole(Smod2.API.RoleType.TUTORIAL);
						player.SetGhostMode(true);
						player.SetGodmode(true);
						player.SetRadioBattery(999);
						player.PersonalBroadcast((ushort)ghostBroadcastTime, ghostBroadcast, false);
						player.SetGhostMode(ghostGhostMode);
						player.SetGodmode(ghostGhostMode);
						player.SetRadioBattery(999);
						player.GiveItem(Smod2.API.ItemType.RADIO);
						player.GiveItem(Smod2.API.ItemType.COIN);
						player.SetGhostMode(true);
					}
					spawnGhost.RemoveAt(i);
				}
			}
		}

		public void OnPlayerPickupItem(PlayerPickupItemEvent ev)
		{
			if (ev.Player.TeamRole.Role == Smod2.API.RoleType.TUTORIAL)
			{
				ev.Allow = false;
			}
		}

		public void OnPlayerDropItem(PlayerDropItemEvent ev)
		{
			if (ev.Player.TeamRole.Role == Smod2.API.RoleType.TUTORIAL)
			{
				List<Player> list = (from item in plugin.PluginManager.Server.GetPlayers()
									 where (item.PlayerId != ev.Player.PlayerId && item.TeamRole.Role != Smod2.API.RoleType.TUTORIAL && item.TeamRole.Team != TeamType.SPECTATOR) && !item.OverwatchMode
									 select item).ToList();

				if (list.Count > 0)
				{
					System.Random random = new System.Random();
					ev.Player.Teleport(list[random.Next(0, list.Count)].GetPosition());
				}

				ev.Allow = false;
			}
		}

        public void OnPlayerDie(PlayerDeathEvent ev)
        {
            if (ev.Killer.TeamRole.Role == Smod2.API.RoleType.SCP_049)
            {
				pos = ev.Killer.GetPosition();
				Timing.CallDelayed(6f, () => ev.Player.ChangeRole(Smod2.API.RoleType.SCP_049_2));
				Timing.CallDelayed(6f, () => ev.Player.Teleport(pos));
            }
		}

        public void OnIntercom(PlayerIntercomEvent ev)
        {
            if (ev.Player.TeamRole.Role == Smod2.API.RoleType.TUTORIAL)
            {
				ev.SpeechTime = 0.1f;
				ev.Player.Teleport(new Vector(0, 0, 0));
            }
        }

        public void OnSCP914ChangeKnob(PlayerSCP914ChangeKnobEvent ev)
        {
			if (ev.Player.TeamRole.Role == Smod2.API.RoleType.TUTORIAL)
			{
				ev.Player.Teleport(new Vector(0, 0, 0));
			}
		}

        public void OnSCP914Activate(SCP914ActivateEvent ev)
        {
            if (ev.User.TeamRole.Role == Smod2.API.RoleType.TUTORIAL)
            {
				ev.User.Teleport(new Vector(0, 0, 0));
			}
        }
	}
}
